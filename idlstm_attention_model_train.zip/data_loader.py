# encoding=utf-8
"""
author:yqtong@stu.xmu.edu.cn
date:2019/10/10
"""
from __future__ import print_function
from __future__ import division
from __future__ import absolute_import
import codecs
from idlstm_intra_attention_model_train import data_utils


def load_sentences(path):
    """
    Load data set,每一行至少包含一个汉字和一个标记
    句子和句子之间是以空格分隔
    最终返回句子集合
    :param path:train/dev/test file path
    :return:list, list_length = sentence number, [[[token,label],[token,label],.....],[...] ...]
    """
    # 存放数据集
    sentences = []
    # 临时存放每一个句子
    sentence = []
    for line in codecs.open(path, 'r', encoding='utf-8'):
        # 去掉两边空格
        line = line.strip().replace('\u200b', '')
        # 首先判断是不是空，如果是则表示句子和句子之间的分割点
        if not line:
            if len(sentence) > 0:
                sentences.append(sentence)
                # 清空sentence，表示一句话完结
                sentence = []
            else:
                continue
        elif line[0] == ' ':
            # 不合法的情况
            continue
        else:
            # 合法的情况
            word = line.split()
            assert len(word) == 2
            # 要考虑到换行符
            sentence.append(word)
            #print(sentence[-1][0])
            assert len(sentence[-1][0]) == 1

    # 循环走完，要判断一下，防止最后一个句子没有进入到句子集合中
    if len(sentence) > 0:
        sentences.append(sentence)
    #print(sentences)
    return sentences


def update_tag_scheme(sentences, tag_scheme):
    """
    更新为指定编码
    :param sentences:
    :param tag_scheme:
    :return:
    """
    for index, s in enumerate(sentences):
        # 取出所有标签,做标签合法性检查
        tags = [w[-1] for w in s]
        if not data_utils.check_bio(tags):
            s_str = '\n'.join(' '.join(w) for w in s)
            raise Exception('输入的句子应为BIO编码,请检查句子%i:\n%s' % (index, s_str))

        if tag_scheme == 'BIO':
            for word, new_tag in zip(s, tags):
                word[-1] = new_tag

        elif tag_scheme == 'BIOES':
            new_tags = data_utils.bio_to_bioes(tags)
            #print(new_tags)
            for word, new_tag in zip(s, new_tags):
                word[-1] = new_tag
        else:
            raise Exception('非法目标编码')


def word_mapping(sentences):
    """
    构建字典
    :param sentences:
    :return:
    """
    word_list = [[x[0] for x in s]for s in sentences]
    # python列表推导式
    word_dict = data_utils.create_dict(word_list)
    word_dict['<PAD>'] = 10000001
    word_dict['<UNK>'] = 10000000
    word_to_id, id_to_word = data_utils.create_mapping(word_dict)
    return word_dict, word_to_id, id_to_word


def tag_mapping(sentences):
    """
    构建标签字典
    :param sentences:
    :return:
    """
    tag_list = [[x[1] for x in s] for s in sentences]
    tag_dict = data_utils.create_dict(tag_list)
    tag_to_id, id_to_tag = data_utils.create_mapping(tag_dict)
    return tag_dict, tag_to_id, id_to_tag


def prepare_dataset(sentences, word_to_id, tag_to_id, train=True):
    """
    数据预处理,返回list,list中包含
    -word_list
    -word_id_list
    -word char indexs
    -tag_id_list
    :param sentences:
    :param word_to_id:
    :param tag_to_id:
    :param train:
    :return:
    """
    none_index = tag_to_id['O']
    data = []
    for s in sentences:
        word_list = [w[0] for w in s]
        word_id_list = [word_to_id[w if w in word_to_id else '<UNK>'] for w in word_list]
        segs = data_utils.get_seg_features(''.join(word_list))
        if train:
            tag_id_list = [tag_to_id[w[-1]] for w in s]
        else:
            tag_id_list = [none_index for w in s]
        data.append([word_list, word_id_list, segs, tag_id_list])

    return data

if __name__ == '__main__':
    path = 'data/bakeoff2006.dev'
    sentences = load_sentences(path)
    update_tag_scheme(sentences, 'BIOES')
    word_dict, word_to_id, id_to_word = word_mapping(sentences)
    tag_dict, tag_to_id, id_to_tag = tag_mapping(sentences)
    dev_data = prepare_dataset(sentences, word_to_id, tag_to_id)
    data_utils.BatchManager(dev_data, 120)