"""
author:yqtong@stu.xmu.edu.cn
date:2020-01-03
"""
from __future__ import print_function
from __future__ import absolute_import
from __future__ import division

import tensorflow as tf
import os
import logging
import time
from idlstm_intra_attention_model_train.model import Model
import json
from idlstm_intra_attention_model_train import model_utils
from idlstm_intra_attention_model_train.data_utils import load_word2vec
flags = tf.app.flags

flags.DEFINE_string('ckpt_path', os.path.join('modelfile', 'ckpt'), 'checkpoint保存位置,即模型保存位置')
flags.DEFINE_string('map_file', 'maps.pkl', '存放字典映射及标签映射')
flags.DEFINE_string('config_file', 'config_file', '配置文件')
flags.DEFINE_string('export_dir', 'exportmodel', '模型导出地址')
flags.DEFINE_string('export_model_name', 'IDLSTM+ATTENTION+CRF', '导出模型名')
FLAGS = tf.app.flags.FLAGS


def load_config(config_file):
    """
    加载配置文件
    :param config_file:
    :return:
    """
    with open(config_file, encoding='utf-8') as fa:
        return json.load(fa)


def export_model():
    """导出模型(TensorFlow serving model)"""

    with tf.get_default_graph().as_default():
        ckpt_state = tf.train.get_checkpoint_state(FLAGS.ckpt_path)
        model_path = os.path.join(FLAGS.ckpt_path, os.path.basename(ckpt_state.model_checkpoint_path))
        print(model_path)
        logger = logging.getLogger('Address')
        config = load_config(FLAGS.config_file)
        tf_config = tf.ConfigProto()
        with tf.Session(config=tf_config) as sess:
            model = model_utils.create(sess, Model, FLAGS.ckpt_path, load_word2vec, config, id_to_word, logger)
            sess.run(tf.global_variables_initializer())
            logger.info('重装模型参数...')
            saver = tf.train.Saver()
            saver.restore(sess, save_path=model_path)

            # check model is exist or not
            export_dir = os.path.join(FLAGS.export_dir, FLAGS.export_model_name)
            if os.path.exists(export_dir):
                new_export_dir = export_dir + '_' + str(int(time.time()))
                logger.warning('model exists! old model will be rename to' + new_export_dir)
                os.rename(export_dir, new_export_dir)

            # start to create model builder
            builder = tf.saved_model.builder.SavedModelBuilder(export_dir)

            # define input and output
            inputs_dict = dict()
            print(type(model.word_inputs))

            indices_word = tf.saved_model.utils.build_tensor_info(model.word_inputs)
            inputs_dict.setdefault('input_vector', indices_word)
            print(inputs_dict)

            logger.info('导出单通道模型...')

            output_classes = tf.saved_model.utils.build_tensor_info(model.logits)
            c = dict()
            c.setdefault('haha', output_classes)
            print(c)
            # 创建预测签名
            signature = (
                tf.saved_model.signature_def_utils.build_signature_def(
                    inputs=indices_word,
                    outputs={
                        'output_vector': output_classes,
                    },
                    method_name=tf.saved_model.signature_constants.PREDICT_METHOD_NAME
                )
            )
            legacy_init_op = tf.group(tf.tables_initializer(), name='legacy_init_op')
            builder.add_meta_graph_and_variables(
                sess, [tf.saved_model.tag_constants.SERVING],
                signature_def_map={
                    tf.saved_model.signature_constants.DEFAULT_SERVING_SIGNATURE_DEF_KEY: signature,
                },
                legacy_init_op=legacy_init_op
            )

            builder.save()
            logger.info('Done exporting!')


def main(_):
    export_model()


if __name__ == '__main__':
    tf.app.run(main)