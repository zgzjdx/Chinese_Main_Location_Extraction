# encoding=utf-8
"""
author:yqtong@stu.xmu.edu.cn
date:2019/10/10
"""
from __future__ import print_function
from __future__ import division
from __future__ import absolute_import
import jieba
import math
import random
import codecs
import numpy as np
import os


def check_bio(tags):
    """
    检测输入的tags是否是bio编码
    如果不是合法的bio编码，将其更改为合法的bio编码
    那么错误的类型有三种
    (1)编码不在bio中
    (2)第一个编码是i
    (3)当前编码不是b，前一个编码不是o
    :param tags:
    :return:
    """
    for index, tag in enumerate(tags):
        if tag == 'O':
            continue
        tag_list = tag.split('-')
        if len(tag_list) != 2 or tag_list[0] not in set(['B', 'I']):
            # 错误类型1
            return False

        if tag_list[0] == 'B':
            continue
        elif index == 0 or tags[index-1] == 'O':
            # 如果第一个位置不是B或者当前编码不是B并且前一个编码是O,则全部转换成B
            tags[index] = 'B' + tag[1:]
        elif tags[index-1][1:] == tag[1:]:
            # 如果当前编码的后面类型编码与tags中的前一个编码中后面类型编码相同则跳过
            continue
        else:
            # 如果编码类型不一致,则重新从B开始编码
            tags[index] = 'B' + tag[1:]
    return True


def bio_to_bioes(tags):
    """
    把bio编码转换成bioes编码,返回新的tags
    :param tags:
    :return:
    """
    new_tags = []
    for index, tag in enumerate(tags):
        if tag == 'O':
            # O直接保留,不变化
            new_tags.append(tag)
            continue
        elif tag.split('-')[0] == 'B':
            # 如果tag以B开头,那么就要做下面的判断
            if (index+1) < len(tags) and tags[index+1].split('-')[0] == 'I':
                # 如果当前tag不是最后一个,并且紧跟着的后一个是I
                new_tags.append(tag)
                continue
            else:
                # 如果是最后一个或者紧跟着的后一个不是I,那么表示是单字,那么需要把B转换成S表示单字
                new_tags.append(tag.replace('B-', 'S-'))
                continue
        elif tag.split('-')[0] == 'I':
            # 如果tag是以I开头,那么我们需要进行下面的判断
            if (index+1) < len(tags) and tags[index+1].split('-')[0] == 'I':
                # 如果当前的tag不是最后一个,并且紧跟着的一个是I,直接保留
                new_tags.append(tag)
                continue
            else:
                # 如果是最后一个,或者后一个不是I开头的,那么表示一个结尾,需要把I换成E
                new_tags.append(tag.replace('I-', 'E-'))
                continue
        else:
            raise Exception('非法编码')
    return new_tags


def bioes_to_bio(tags):
    """
    BIOES->BIO
    :param tags:
    :return:
    """
    new_tags = []
    for index, tag in enumerate(tags):
        if tag.split('-')[0] == 'B':
            new_tags.append(tag)
        elif tag.split('-')[0] == 'I':
            new_tags.append(tag)
        elif tag.split('-')[0] == 'S':
            new_tags.append(tag.replace('S-', 'B-'))
        elif tag.split('-')[0] == 'E':
            new_tags.append(tag.replace('E-', 'I-'))
        elif tag.split('-')[0] == 'O':
            new_tags.append(tag)
        else:
            raise Exception('非法编码')
    return new_tags


def create_dict(item_list):
    """
    对于item_list中的每一个item,统计items中的item在item_list中的次数
    item:出现的次数
    :param item_list:
    :return:
    """
    assert type(item_list) is list
    dico = {}
    for items in item_list:
        for item in items:
            if item not in dico:
                dico[item] = 1
                continue
            else:
                dico[item] += 1
                continue
    return dico


def create_mapping(dico):
    """
    创建item_to_id, id_to_item
    item的排序按词典中出现的次数降序
    :param dico:
    :return:
    """
    sorted_items = sorted(dico.items(), key=lambda x: (-x[1], x[0]))
    # 如果次数相同，按词进行排序
    id_to_item = {item: value[0] for item, value in enumerate(sorted_items)}
    # item就是id value[0]就是词
    item_to_id = {value:key for key,value in id_to_item.items()}

    # 把id_to_item里的key,value反转一下
    return item_to_id, id_to_item


def get_seg_features(words):
    """
    输入一串字符串，利用结巴分词
    采用类似bio的编码,0表示单字成词,1表示词的开始,2表示词的中间,3表示词的结尾
    :param words:
    :return:
    """
    seg_features = []
    word_list = list(jieba.cut(words))
    for word in word_list:
        if len(word) == 1:
            # 单字成词
            seg_features.append(0)
        else:
            temp = [2]*len(word)
            # 先全部设成2
            temp[0] = 1
            temp[-1] = 3
            seg_features.extend(temp)
    return seg_features


def load_word2vec(emb_file, id_to_word, word_dim, old_weights):
    """
    :param emb_file:
    :param id_to_word:
    :param word_dim:
    :param old_weights:
    :return:
    """
    new_weights = old_weights
    pre_trained = {}
    emb_invalid = 0
    for index, line in enumerate(codecs.open(emb_file, 'r', encoding='utf-8')):
        line = line.rstrip().split(' ')
        if len(line) == word_dim + 1:
            pre_trained[line[0]] = np.array(
                [float(x) for x in line[1:]]
            ).astype(np.float32)
        else:
            # 无效词向量
            emb_invalid += 1

    if emb_invalid > 0:
        print('warning:%i invalid lines' % emb_invalid)

    num_words = len(id_to_word)
    for idx in range(num_words):
        word = id_to_word[idx]
        if word in pre_trained:
            new_weights[idx] = pre_trained[word]
        else:
            pass
    print('加载了%i个字向量' % len(pre_trained))

    return new_weights


def augment_with_pretrained(dico_train, emb_path, test_words):
    """
    :param dico_train:
    :param emb_path:
    :param test_words:
    :return:
    """
    assert os.path.isfile(emb_path)
    # 加载预训练词向量
    pretrained = set(
        [
            line.rstrip().split()[0].strip() for line in codecs.open(emb_path, 'r', encoding='utf-8')
        ]
    )

    if test_words is None:
        for word in pretrained:
            if word not in dico_train:
                dico_train[word] = 0
    else:
        for word in test_words:
            if any(x in pretrained for x in [word, word.lower()]) and word not in dico_train:
                dico_train[word] = 0
    word_to_id, id_to_word = create_mapping(dico_train)
    return dico_train, word_to_id, id_to_word


class BatchManager(object):
    # 新建一个类要继承object
    def __init__(self, data, batch_size):
        # 类初始化
        self.batch_data = self.sort_and_pad(data, batch_size)
        self.len_data = len(self.batch_data)

    def sort_and_pad(self, data, batch_size):
        batch_num = int(math.ceil(len(data) / batch_size))
        # 有多少批次, math.ceil向上取整
        sorted_data = sorted(data, key=lambda x:len(x[0]))
        # 升序排序
        batch_data = list()
        for idx in range(batch_num):
            batch_data.append(self.pad_data(sorted_data[idx*batch_size:(idx+1)*batch_size]))
        return batch_data

    @staticmethod
    def pad_data(data):
        # 静态方法没有self参数,可以看做一个普通的函数
        word_list = []
        word_id_list = []
        seg_list = []
        tag_id_list = []
        max_length = max([len(sentence[0]) for sentence in data])
        # 取该batch中最长的
        for line in data:
            words, word_ids, segs, tag_ids = line
            padding = [0] * (max_length - len(words))
            # 要padding的数量，保证每一批的维度是一致的
            word_list.append(words + padding)
            word_id_list.append(word_ids + padding)
            seg_list.append(segs + padding)
            tag_id_list.append(tag_ids + padding)
        return [word_list, word_id_list, seg_list, tag_id_list]

    def iter_batch(self, shuffle=False):
        """
        对数据做shuffle操作，默认不做
        :param shuffle:
        :return:
        """
        if shuffle:
            random.shuffle(self.batch_data)
        for idx in range(self.len_data):
            #print(self.batch_data[idx])
            yield self.batch_data[idx]







