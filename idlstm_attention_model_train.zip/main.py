# encoding=utf-8
"""
author:yqtong@stu.xmu.edu.cn
date:2019/10/10
"""
from __future__ import print_function
from __future__ import division
from __future__ import absolute_import
from idlstm_intra_attention_model_train.model import Model
# 系统包
import warnings
warnings.filterwarnings('ignore')
import os
import tensorflow as tf
import pickle
import numpy as np
import itertools
# 自定义包
from idlstm_intra_attention_model_train.data_utils import load_word2vec
from idlstm_intra_attention_model_train import data_loader, data_utils, model_utils

flags = tf.app.flags

flags.DEFINE_boolean('train', True, '是否开始训练')
flags.DEFINE_boolean('clean', True, '是否清理临时文件')

# 配置相关
flags.DEFINE_integer('seg_dim', 20, '分词维度,seg embedding size')
flags.DEFINE_integer('word_dim', 100, 'word embedding size')
flags.DEFINE_integer('lstm_dim',100, 'LSTM隐层维度, number of hidden unit in lstm')
flags.DEFINE_string('tag_scheme', 'BIOES', '编码方式')

# 训练相关
flags.DEFINE_float('clip', 5, '梯度裁剪,grandient clip')
flags.DEFINE_float('dropout', 0.5, '剪枝率,dropout rate')
flags.DEFINE_integer('batch_size', 120, 'batch size')
flags.DEFINE_float('lr', 0.001, '学习率,learning rate')
flags.DEFINE_string('optimizer', 'adam', '优化器')
flags.DEFINE_boolean('pre_emb', True, '是否用预训练词向量')
flags.DEFINE_integer('max_epoch', 100, '最大轮训次数')
flags.DEFINE_integer('steps_checkpoint', 100, '训练多少步保存checkpoint')
flags.DEFINE_string('ckpt_path', os.path.join('modelfile', 'ckpt'), 'checkpoint保存位置,即模型保存位置')
flags.DEFINE_string('log_file', 'log.out', '训练日志')
flags.DEFINE_string('map_file', 'maps.pkl', '存放字典映射及标签映射')
flags.DEFINE_string('vocab_file', 'vocab.json', '存放词典')
flags.DEFINE_string('result_path', 'result', '结果路径')
flags.DEFINE_string('config_file', 'config_file', '配置文件')
flags.DEFINE_string('emb_file', os.path.join('data', 'wiki_100.utf8'), '词向量文件路径')
flags.DEFINE_string('train_file', os.path.join('data', 'bakeoff2006.train'), '训练数据路径')
flags.DEFINE_string('dev_file', os.path.join('data', 'bakeoff2006.dev'), '校验数据路径')
flags.DEFINE_string('test_file', os.path.join('data', 'bakeoff2006.test'), '测试数据路径')
flags.DEFINE_string('model_type', 'idlstm_intra_attention', '模型选择（idcnn or bilstm or idlstm or idlstm_intra_attention)')

FLAGS = tf.app.flags.FLAGS
assert FLAGS.clip < 5.1, '梯度裁剪不能过大'
assert 0 < FLAGS.dropout < 1, 'dropout必须在0和1之间'
assert FLAGS.lr > 0, '学习率必须大于零'
assert FLAGS.optimizer in ['adam', 'sgd', 'adagrad'], '优化器必须是adam或sgd或adagrad'


def random_embedding(vocab, embedding_dim):
    """
    :param vocab:
    :param embedding_dim:
    :return:
    """
    embedding_mat = np.random.uniform(-0.25, 0.25, (len(vocab), embedding_dim))
    embedding_mat = np.float32(embedding_mat)
    return embedding_mat


def evaluate(sess, model, name, manager, id_to_tag, logger):
    logger.info('evaluate:{}'.format(name))
    ner_result = model.evaluate(sess, manager, id_to_tag)
    eval_lines = model_utils.test_ner(ner_result, FLAGS.result_path)
    for line in eval_lines:
        logger.info(line)
    f1 = float(eval_lines[1].strip().split()[-1])

    if name == 'dev':
        best_test_f1 = model.best_dev_f1.eval()
        if f1 > best_test_f1:
            tf.assign(model.best_test_f1, f1).eval()
            logger.info('new best f1 score:{:>.3f}'.format(f1))
        return f1 > best_test_f1
    elif name == 'test':
        best_test_f1 = model.best_test_f1.eval()
        if f1 > best_test_f1:
            tf.assign(model.best_test_f1, f1).eval()
            logger.info('new best f1 score:{:>.3f}'.format(f1))
        return f1 > best_test_f1


def train():
    # 加载数据集
    train_sentences = data_loader.load_sentences(FLAGS.train_file)
    dev_sentences = data_loader.load_sentences(FLAGS.dev_file)
    test_sentences = data_loader.load_sentences(FLAGS.test_file)
    print('load over')
    # 转换编码 bio->bioes
    data_loader.update_tag_scheme(train_sentences, FLAGS.tag_scheme)
    data_loader.update_tag_scheme(dev_sentences, FLAGS.tag_scheme)
    data_loader.update_tag_scheme(test_sentences, FLAGS.tag_scheme)
    print('convert over')
    # 创建单词映射及标签映射
    if not os.path.isfile(FLAGS.map_file):
        if FLAGS.pre_emb:
            # 用预训练的话，先过滤一下
            train_words_dict = data_loader.word_mapping(train_sentences)[0]
            _, word_to_id, id_to_word = data_utils.augment_with_pretrained(
                train_words_dict.copy(),
                FLAGS.emb_file,
                list(itertools.chain.from_iterable([[w[0] for w in s]for s in test_sentences]))
            )
        else:
            _, word_to_id, id_to_word = data_loader.word_mapping(train_sentences)

        _, tag_to_id, id_to_tag = data_loader.tag_mapping(train_sentences)
        with open(FLAGS.map_file, 'wb') as fa:
            pickle.dump([word_to_id, id_to_word, tag_to_id, id_to_tag], fa)
    else:
        with open(FLAGS.map_file, 'rb') as fa:
            word_to_id, id_to_word, tag_to_id, id_to_tag = pickle.load(fa)
    # 数据预处理
    train_data = data_loader.prepare_dataset(
        train_sentences, word_to_id, tag_to_id
    )
    dev_data = data_loader.prepare_dataset(
        dev_sentences, word_to_id, tag_to_id
    )
    test_data = data_loader.prepare_dataset(
        test_sentences, word_to_id, tag_to_id
    )
    train_manager = data_utils.BatchManager(train_data, FLAGS.batch_size)
    dev_manager = data_utils.BatchManager(dev_data, FLAGS.batch_size)
    test_manager = data_utils.BatchManager(test_data, FLAGS.batch_size)

    print('train_data_number %i, dev_data_number %i, test_data_number %i' %(len(train_data),len(dev_data),len(test_data)))
    print('preprocess over')

    # 模型参数加载与保存
    model_utils.make_path(FLAGS)
    if os.path.isfile(FLAGS.config_file):
        config = model_utils.load_config(FLAGS.config_file)
    else:
        config = model_utils.config_model(FLAGS, word_to_id, tag_to_id)
        model_utils.save_config(config, FLAGS.config_file)
    print('read config file over')

    log_path = os.path.join('log', FLAGS.log_file)
    logger = model_utils.get_logger(log_path)
    model_utils.print_config(config, logger)
    print('load log file over')

    tf_config = tf.ConfigProto()
    tf_config.gpu_options.allow_growth = True
    steps_per_epoch = train_manager.len_data
    with tf.Session(config=tf_config) as sess:
        model = model_utils.create(sess, Model, FLAGS.ckpt_path, load_word2vec, config, id_to_word, logger)
        logger.info('开始训练')
        loss = []
        for idx in range(50):
            for batch in train_manager.iter_batch(shuffle=True):
                step, batch_loss = model.run_step(sess, True, batch)
                loss.append(batch_loss)
                if step % FLAGS.steps_checkpoint == 0:
                    iteration = step // steps_per_epoch + 1
                    # 地板除
                    logger.info('iteration:{} step{}/{}, NER loss:{:9.6f}'.format(
                        iteration, step%steps_per_epoch, steps_per_epoch, np.mean(loss)))
                    loss = []
                    # 日志清空
            best = evaluate(sess, model, 'dev', dev_manager, id_to_tag, logger)
            if best:
                model_utils.save_model(sess, model, FLAGS.ckpt_path, logger)
            evaluate(sess, model, 'test', test_manager, id_to_tag, logger)


def main(_):
    if FLAGS.train:
        train()
    else:
        pass


if __name__ == '__main__':
    tf.app.run(main)




















